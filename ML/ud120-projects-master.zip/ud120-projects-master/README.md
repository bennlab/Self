ud120-projects
==============

Starter project code for students taking Udacity ud120

### Setup
- Create a virtual environment for Python 3.9 or higher.
- $ pip install -r requirements.txt

### Contribution Note
The code in this repo has been upgraded from Python 2 to Python 3 by [Siddharth Kekre](https://github.com/iSiddharth20) in this [PR](https://github.com/udacity/ud120-projects/pull/302). Refer to the [Change Log](https://github.com/iSiddharth20/ud120-projects/blob/master/CHANGELOG.md) for more details. 
